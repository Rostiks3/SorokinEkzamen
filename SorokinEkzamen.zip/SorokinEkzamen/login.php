<?php
$host = 'localhost'; // имя хоста
$user = 'root';      // имя пользователя
$pass = '';          // пароль
$name = 'ekzamen';      // имя базы данных
$link = mysqli_connect($host, $user, $pass, $name);
session_start();
if (!empty($_GET['pass']) && !empty($_GET['email'])) 
{
	$email = $_GET['email'];
	$query = "SELECT * FROM klient WHERE email='$email'"; 
	$res = mysqli_query($link, $query);
	$user = mysqli_fetch_assoc($res);
	if (!empty($user)) 
	{
		$pass = md5($_GET['pass']);
		$hash = $user['Pass'];
		if ($_GET['pass'] == $hash) {
			$_SESSION['auth'] = true;
			$_SESSION['email'] = $email;
			echo "<script>alert('Вы успешно авторизовались!')</script>";
		header("Refresh: 0; index.php");
		} else 
		{
			echo "<script>alert('Неверно введен пароль!')</script>";
		}
	} 
	else  
	{
		echo "<script>alert('Пользователь с такой почтой не найден!')</script>";
	}
}
?>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<a href="index.php"><img src="images/logo.png" alt="Company Logo" class="logo"></a>
		<div class="contact-info">
			<a href="tel:+78001234567" class="phone-number">+7 (800) 123-45-67</a>
			<a href="test@mail.com" class="email">test@mail.com</a>
		</div>
		<div>
		<button onclick="location.href='reg.php';">Регистрация</button>
		<button onclick="location.href='login.php';">Авторизация</button>
		</div>
	</header>
	<nav class="nav-top">
		<ul class="horizontal-menu">
				<li><a href="#">Модели</a></li>
				<li><a href="#">Авто в наличии</a></li>
				<li><a href="#">Покупателям</a></li>
				<li><a href="#">Владельцам</a></li>
				<li><a href="#">Контакты</a></li>
		</ul>
	</nav>
	<main>
		<div class="form-container">
			<h2>Авторизация</h2>
			<form class="login-form" method="GET" action="">
			<label for="email">Email:</label><br>
			<input type="email" id="email" name="email" pattern=".*@.*\..*" required><br>
			<label for="pass">Пароль:</label><br>
			<input type="password" id="pass" name="pass" maxlength="25" minlength="3" required><br>
				<input type="submit" value="Войти">
			</form>
		</div>
	</main>
	<footer class="footer">
		<div class="footer-content">
			<div class="footer-contact">
				<p>г. Ярославль, ул. Пушкина 10</p>
				<p href="tel:+78001234567" class="phone-number">+7 (800) 123-45-67</a>
				<p href="test@mail.com" class="email">test@mail.com</a>
			</div>
			<nav class="footer-nav">
				<ul>
					<li><a href="#">Модели</a></li>
					<li><a href="#">Авто в наличии</a></li>
					<li><a href="#">Покупателям</a></li>
					<li><a href="#">Владельцам</a></li>
					<li><a href="#">Контакты</a></li>
				</ul>
			</nav>
		</div>
	</footer>
</body>
</html>