-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 19 2024 г., 09:04
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ekzamen`
--

-- --------------------------------------------------------

--
-- Структура таблицы `polzovatel`
--

CREATE TABLE `polzovatel` (
  `id_polzovatelya` int(11) NOT NULL,
  `Familia` varchar(100) NOT NULL,
  `Imya` varchar(100) NOT NULL,
  `Otchestvo` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Telefon` varchar(12) NOT NULL,
  `Login` varchar(25) NOT NULL,
  `Pass` varchar(25) NOT NULL,
  `id_roli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп данных таблицы `polzovatel`
--

INSERT INTO `polzovatel` (`id_polzovatelya`, `Familia`, `Imya`, `Otchestvo`, `Email`, `Telefon`, `Login`, `Pass`, `id_roli`) VALUES
(1, 'Иванов', 'Иван', 'Иванович', 'ivan@mail.ru', '+78001234567', 'admin', 'Fs~j4Ms|Go', 2),
(2, 'Сорокин', 'Егор', 'Александрович', 'egor@mail.ru', '+71111111111', 'Egor', '123', 1),
(3, 'Петров', 'Петр', 'Петрович', 'petr@gmail.com', '+71231231212', 'Petr1', '123', 1),
(4, 'Александров', 'Александр', 'Александрович', 'alex@rambler.ru', '+73211233212', 'Alex333', '333', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `rol`
--

CREATE TABLE `rol` (
  `id_roli` int(11) NOT NULL,
  `Rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп данных таблицы `rol`
--

INSERT INTO `rol` (`id_roli`, `Rol`) VALUES
(1, 'Клиент'),
(2, 'Менеджер');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `polzovatel`
--
ALTER TABLE `polzovatel`
  ADD PRIMARY KEY (`id_polzovatelya`),
  ADD KEY `id_roli` (`id_roli`);

--
-- Индексы таблицы `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_roli`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `polzovatel`
--
ALTER TABLE `polzovatel`
  MODIFY `id_polzovatelya` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `rol`
--
ALTER TABLE `rol`
  MODIFY `id_roli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `polzovatel`
--
ALTER TABLE `polzovatel`
  ADD CONSTRAINT `polzovatel_ibfk_1` FOREIGN KEY (`id_roli`) REFERENCES `rol` (`id_roli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
