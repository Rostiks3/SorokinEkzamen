<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Экзамен</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<a href="index.php"><img src="images/logo.png" alt="Logo" class="logo"></a>
		<ul>
				<li><a>+7 (800) 123-45-67</a></li>
				<li><a>test@mail.com</a></li>
		</ul>
		<div>
		<button onclick="location.href='reg.php';">Регистрация</button>
		<button onclick="location.href='login.php';">Авторизация</button>
		</div>
	</header>
	<nav>
		<ul class="horizontal-menu">
				<li><a href="#">Модели</a></li>
				<li><a href="#">Авто в наличии</a></li>
				<li><a href="#">Покупателям</a></li>
				<li><a href="#">Владельцам</a></li>
				<li><a href="#">Контакты</a></li>
		</ul>
	</nav>
    <main>
		<div class="company-block">
			<h2>О компании</h2>
			<p>
			Мы, ведущая компания в сфере автомобильных продаж и обслуживания. С 2024 года мы стремимся обеспечить наших клиентов самым широким выбором высококачественных автомобилей и выдающимся уровнем обслуживания.

			Наш автосалон является надежным партнером для всех, кто ищет надежные, стильные и инновационные автомобили. Мы предлагаем широкий ассортимент марок и моделей, от премиальных автомобилей до надежных семейных внедорожников.
			
			Наша команда состоит из опытных профессионалов, которые готовы помочь вам выбрать автомобиль, соответствующий вашим потребностям и бюджету. Мы стремимся к высочайшему уровню обслуживания, предлагая нашим клиентам индивидуальный подход и персонализированные решения.
			</p>
			<p>
				г. Ярославль, ул. Пушкина 10
			</p>
			<button>Связаться с нами</button>
		</div>
		<div>
			<h1>Новые модели</h1>
			<div class="cards">
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
				<div class="property-card">
					<img src="images/object1.jpg" alt="Image">
					<div>
						<h2>Автомобиль</h2>
						<p>10 000 000 руб.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="reviews-block">
			<h2>Отзывы клиентов</h2>
			<div class="review-card">
				<p class="review-text">
					Прекрасный выбор автомобилей и внимательный персонал! Благодаря автосалону я нашел идеальный автомобиль без лишних хлопот. Рекомендую всем! 
				</p>
				<p class="review-author">
					- Валерия
				</p>
			</div>
			<div class="review-card">
				<p class="review-text">
					Отличный сервис и профессиональный подход! Мой опыт покупки автомобиля в этом автосалоне был безупречным. Спасибо команде за помощь в выборе и приятное обслуживание!
				</p>
				<p class="review-author">
					- Олег
				</p>
			</div>
		</div>
		<div class="reg-block">
			<h2>Зарегистрированные пользователи</h2>
		<?php
$host = 'localhost'; // имя хоста
$user = 'root';      // имя пользователя
$pass = '';          // пароль
$name = 'ekzamen';      // имя базы данных
    $con = mysqli_connect($host, $user, $pass, $name);
    if(!$con)
    {
        die("Ошибка!" . mysqli_connect_error());
    }
    $sql = "SELECT * FROM klient";
    $result = mysqli_query($con, $sql);
    if(mysqli_num_rows($result) > 0)
    {
       echo '<table> <tr> <th> Фамилия </th> <th> Имя </th> <th> Отчество </th> </tr>';
       while($row = mysqli_fetch_assoc($result)){
           echo '<td>' . $row["Familia"] . '</td>
           <td> ' . $row["Imya"] . '</td>
           <td>' . $row["Otchestvo"] . '</td> </tr>';
       }
       echo '</table>';
    }
    else
    {
        echo "0 results";
    }
    mysqli_close($con);
?>
		</div>
    </main>
	<footer class="footer">
		<div class="footer-content">
			<div class="footer-contact">
				<p>г. Ярославль, ул. Пушкина 10</p>
				<p href="tel:+78001234567" class="phone-number">+7 (800) 123-45-67</a>
				<p href="test@mail.com" class="email">test@mail.com</a>
			</div>
			<nav class="footer-nav">
				<ul>
					<li><a href="#">Модели</a></li>
					<li><a href="#">Авто в наличии</a></li>
					<li><a href="#">Покупателям</a></li>
					<li><a href="#">Владельцам</a></li>
					<li><a href="#">Контакты</a></li>
				</ul>
			</nav>
		</div>
	</footer>
</body>
</html>