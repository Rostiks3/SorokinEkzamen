<?php
$host = 'localhost'; // имя хоста
$user = 'root';      // имя пользователя
$pass = '';          // пароль
$name = 'ekzamen';      // имя базы данных
$link = mysqli_connect($host, $user, $pass, $name);
if (!empty($_GET)) 
{
	$email = $_GET['email'];
	$login = $_GET['login'];
	$telefon = $_GET['telefon'];
	$query = "SELECT * FROM klient WHERE email='$email' || login='$login' || telefon='$telefon'"; 
	$res = mysqli_query($link, $query);
	$user = mysqli_fetch_assoc($res);
	if (!empty($user)) {
		$emailcheck = $user['email'];
		$logincheck = $user['login'];
		$telefoncheck = $user['telefon'];
		if ($_GET['email'] == $emailcheck) {
			echo "<script>alert('Пользователь с такой почтой уже существует!')</script>";
		} 
		if ($_GET['login'] == $logincheck) {
			echo "<script>alert('Пользователь с таким логином уже существует!')</script>";
		} 
		if ($_GET['telefon'] == $telefoncheck) {
			echo "<script>alert('Пользователь с таким номером уже существует!')</script>";
		} 
	}
	else 
	{
		$fam = $_GET['fam'];
		$imya = $_GET['imya'];
		$otch = $_GET['otch'];
		$email = $_GET['email'];
		$telefon = $_GET['telefon'];
		$login = $_GET['login'];
		$pass = $_GET['pass'];
		$query = "INSERT INTO klient SET Familia='$fam', Imya='$imya', Otchestvo='$otch', Email='$email', Telefon='$telefon', Login='$login', Pass='$pass', id_roli='1'";
		mysqli_query($link, $query) or die(mysqli_error($link));
		echo "<script>alert('Вы успешно зарегистрировались!')</script>";
		header("Refresh: 0; index.php");
	}
} 
?>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<a href="index.php"><img src="images/logo.png" alt="Company Logo" class="logo"></a>
		<div class="contact-info">
			<a href="tel:+78001234567" class="phone-number">+7 (800) 123-45-67</a>
			<a href="test@mail.com" class="email">test@mail.com</a>
		</div>
		<div>
		<button onclick="location.href='reg.php';">Регистрация</button>
		<button onclick="location.href='login.php';">Авторизация</button>
		</div>
	</header>
	<nav class="nav-top">
		<ul class="horizontal-menu">
				<li><a href="#">Модели</a></li>
				<li><a href="#">Авто в наличии</a></li>
				<li><a href="#">Покупателям</a></li>
				<li><a href="#">Владельцам</a></li>
				<li><a href="#">Контакты</a></li>
		</ul>
	</nav>
	<main>
		<div class="form-container">
		  <h2 class="property-cards-title">Регистрация</h2>
		  <form class="register-form" method="GET">
			<label for="fam">Фамилия*:</label><br>
			<input type="text" id="fam" name="fam" required><br>
			<label for="imya">Имя*:</label><br>
			<input type="text" id="imya" name="imya" required><br>
			<label for="otch">Отчество*:</label><br>
			<input type="text" id="otch" name="otch" required><br>
			<label for="email">Email*, например: ivan@mail.ru:</label><br>
			<input type="email" id="email" name="email" pattern=".*@.*\..*" required><br>
			<label>Телефон*, например: +78001234567:</label>
			<input type="phone" id="telefon" name="telefon" pattern="[+]{1}[0-9]{11}" maxlength="12" minlength="12" required><br>
			<label for="login">Логин (от 3 до 25 символов)*:</label><br>
			<input type="text" id="login" name="login" maxlength="25" minlength="3"  required><br>
			<label for="password">Пароль (от 3 до 25 символов)*:</label><br>
			<input type="password" id="pass" name="pass" maxlength="25" minlength="3" required><br>
			<input type="submit" value="Зарегистрироваться">
		  </form>
		</div>
	</main>
	<footer class="footer">
		<div class="footer-content">
			<div class="footer-contact">
				<p>г. Ярославль, ул. Пушкина 10</p>
				<p href="tel:+78001234567" class="phone-number">+7 (800) 123-45-67</a>
				<p href="test@mail.com" class="email">test@mail.com</a>
			</div>
			<nav class="footer-nav">
				<ul>
					<li><a href="#">Модели</a></li>
					<li><a href="#">Авто в наличии</a></li>
					<li><a href="#">Покупателям</a></li>
					<li><a href="#">Владельцам</a></li>
					<li><a href="#">Контакты</a></li>
				</ul>
			</nav>
		</div>
	</footer>
</body>
</html>